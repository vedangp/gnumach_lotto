#ifndef __LINUX_SPINLOCK_H
#define __LINUX_SPINLOCK_H
#include <asm/spinlock.h>
#endif
